<?php
/**
 * Plugin Name:       Carousel
 * Description:       Handles the custom functions for the carousel plugin
 * Version:           1.10.3
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Ntombizanele Moni and Haniah Jarden
*/
?>